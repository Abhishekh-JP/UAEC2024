import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def send_email_alert(to_email, subject, message):
    """
    Sends an email alert using an SMTP server.

    Parameters:
        to_email (str): Recipient's email address.
        subject (str): Subject of the email.
        message (str): Body content of the email.
    """
    # Email server configuration
    smtp_server = 'smtp.office365.com'  # or 'smtp.office365.com' for Outlook
    smtp_port = 587
    smtp_user = 'accuseless90@outlook.com'  # Replace with your email
    smtp_password = 'uselessacc123'  # Replace with your app password if 2FA is enabled

    # Set up the email content
    msg = MIMEMultipart()
    msg['From'] = smtp_user
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(message, 'plain'))

    try:
        # Connect to the SMTP server and send the email
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()  # Secure the connection
            server.login(smtp_user, smtp_password)
            server.send_message(msg)
            print("Email sent successfully!")
    except Exception as e:
        print(f"Failed to send email: {e}")

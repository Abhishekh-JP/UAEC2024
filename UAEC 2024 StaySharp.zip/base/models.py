from django.db import models
from django.contrib.auth.models import User

class DrowsinessCheck(models.Model):
    """
    Stores a record of each drowsiness check, including the heart rate variability (HRV),
    average heart rate, and overall state (e.g., 'Alert', 'Slightly Drowsy', 'Critically Drowsy').
    """
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    hrv = models.FloatField()
    average_hr = models.FloatField()
    state = models.CharField(max_length=50)

    def __str__(self):
        return f"DrowsinessCheck by {self.user.username} at {self.timestamp} - State: {self.state}"

class AlertLog(models.Model):
    """
    Logs alerts that have been sent to users, allowing tracking of when an alert was issued
    and for which drowsiness state.
    """
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    alert_timestamp = models.DateTimeField(auto_now_add=True)
    message = models.TextField()
    state = models.CharField(max_length=50)  # Stores the state that triggered the alert (e.g., "Critically Drowsy")

    def __str__(self):
        return f"AlertLog for {self.user.username} at {self.alert_timestamp} - State: {self.state}"

class UserProfile(models.Model):
    """
    Extends the default user model to store additional user-specific information if needed.
    For example, we could store baseline heart rate, preferred email for notifications, etc.
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    baseline_hr = models.FloatField(default=70.0)  # Optional baseline heart rate for analysis
    preferred_email = models.EmailField(blank=True, null=True)  # Optional, in case user wants alerts sent elsewhere

    def __str__(self):
        return f"UserProfile for {self.user.username}"



from django.shortcuts import render
from django.utils import timezone
from .heart_rate_analysis import generate_heart_rate_data, infer_state, generate_24_hour_data, generate_graph
from .models import DrowsinessCheck

# Renders the home page
def home_view(request):
    return render(request, 'base/index.html')

# Renders the monitoring page with heart rate analysis and drowsiness check
def monitor_view(request):
    heart_rate_data = generate_heart_rate_data()  # Generate current heart rate data
    analysis = infer_state(heart_rate_data)  # Analyze heart rate data for drowsiness

    # Save drowsiness check in the database
    check = DrowsinessCheck.objects.create(
        user=request.user,
        timestamp=timezone.now(),
        hrv=analysis["HRV"],
        average_hr=analysis["AverageHR"],
        state=analysis["OverallState"]
    )

    # Determine if alert is needed based on drowsiness state
    alert_needed = analysis["OverallState"] in ["Critically Drowsy", "Slightly Drowsy"]

    return render(request, 'base/monitor.html', {
        'analysis': analysis,
        'alert_needed': alert_needed
    })

# Renders the alert page with an appropriate message based on drowsiness state
def alert_view(request):
    analysis_state = request.GET.get('state', 'unknown')  # Get drowsiness state from request

    # Determine alert message based on drowsiness level
    if analysis_state == "Critically Drowsy":
        alert_message = "High drowsiness detected! Please take a break immediately."
    elif analysis_state == "Slightly Drowsy":
        alert_message = "Slight drowsiness detected. Consider taking a break if you feel tired."
    else:
        alert_message = "Stay safe and monitor your health."

    return render(request, 'base/alert.html', {
        'alert_message': alert_message
    })

# Renders the daily report page with heart rate and HRV data for the past 24 hours
def daily_report_view(request):
    # Generate 24-hour timestamps, heart rate, and HRV data
    timestamps, heart_rate_data, hrv_data = generate_24_hour_data()
    combined_data = list(zip(timestamps, heart_rate_data, hrv_data))  # Combine data for display

    # Generate graphical data for display
    graph_data = generate_graph(heart_rate_data, hrv_data, timestamps)

    return render(request, 'base/daily_report.html', {
        'combined_data': combined_data,
        'graph_data': graph_data,
    })

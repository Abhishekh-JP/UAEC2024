from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.mail import send_mail
from django.conf import settings
from .models import DrowsinessCheck

@receiver(post_save, sender=DrowsinessCheck)
def send_drowsiness_alert(sender, instance, **kwargs):
    if instance.state == "Highly Drowsy (Critical Drowsiness)":
        subject = "Drowsiness Alert: Immediate Attention Required"
        message = f"Dear {instance.user.username},\n\nOur monitoring system has detected high drowsiness in your latest check. Please take a break and prioritize your safety.\n\nBest regards,\nHealth Monitoring Team"
        
        send_mail(
            subject,
            message,
            settings.DEFAULT_FROM_EMAIL,
            [instance.user.email],
            fail_silently=False,
        )

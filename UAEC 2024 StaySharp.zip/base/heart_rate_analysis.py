import numpy as np
import random
from datetime import timedelta, datetime
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import io
import base64

# Generates 24 hours of heart rate and HRV data starting from a specified time
def generate_24_hour_data(start_time=None):
    if start_time is None:
        start_time = datetime.now()
    
    heart_rate_data = []
    hrv_data = []
    current_hr = 70  # Starting heart rate

    for hour in range(24):
        # Simulate heart rate fluctuations
        fluctuation = random.uniform(-20, 20)
        current_hr = max(40, round(current_hr + fluctuation, 2))
        heart_rate_data.append(current_hr)

        # Calculate HRV based on simulated short-term HR data
        hrv_value = calculate_hrv_rmssd([current_hr for _ in range(30)])
        hrv_data.append(round(hrv_value, 2))

        # Periodically adjust heart rate downward
        if hour % 6 == 0:
            current_hr -= round(random.uniform(0, 5), 2)

    # Generate timestamps for each hour
    timestamps = [start_time + timedelta(hours=h) for h in range(24)]
    return timestamps, heart_rate_data, hrv_data

# Generates a graph of heart rate and HRV data over 24 hours and encodes it as a base64 image
def generate_graph(heart_rate_data, hrv_data, timestamps):
    plt.figure(figsize=(10, 5))
    plt.plot(timestamps, heart_rate_data, label='Heart Rate')
    plt.plot(timestamps, hrv_data, label='HRV', linestyle='--')
    
    # Format x-axis with time and date labels
    ax = plt.gca()
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M\n%m-%d'))
    ax.xaxis.set_major_locator(mdates.HourLocator(interval=3))
    
    plt.xlabel('Time and Date')
    plt.ylabel('Values')
    plt.title('Daily Heart Rate and HRV')
    plt.legend()
    
    # Save plot to buffer and encode as base64
    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight')
    plt.close()
    graph_data = base64.b64encode(buf.getvalue()).decode('utf-8')
    return graph_data

# Generates heart rate data for a specified number of seconds with simulated fluctuations
def generate_heart_rate_data(seconds=30, baseline_hr=70):
    heart_rate_data = []
    current_hr = baseline_hr
    
    for _ in range(seconds):
        fluctuation = random.uniform(-20, 20)
        current_hr = max(40, round(current_hr + fluctuation, 2))
        heart_rate_data.append(current_hr)
        baseline_hr -= round(random.uniform(0, 0.05), 2)
    
    return heart_rate_data

# Calculates HRV using RMSSD (Root Mean Square of Successive Differences)
def calculate_hrv_rmssd(heart_rate_data):
    rr_intervals = np.diff(heart_rate_data)
    squared_diff = np.square(rr_intervals)
    rmssd = np.sqrt(np.mean(squared_diff))
    return round(rmssd, 2)

# Calculates the average heart rate from a data set
def calculate_average_heart_rate(heart_rate_data):
    return round(np.mean(heart_rate_data), 2)

# Checks for large fluctuations in heart rate data exceeding a given threshold
# def has_large_fluctuation(heart_rate_data, threshold=25):
#     return any(abs(earlier - later) > threshold for earlier, later in zip(heart_rate_data, heart_rate_data[1:]))

# Infers drowsiness state based on HRV, average heart rate, and fluctuations
def infer_state(heart_rate_data):
    hrv = calculate_hrv_rmssd(heart_rate_data)
    avg_hr = calculate_average_heart_rate(heart_rate_data)
    # large_fluctuation = has_large_fluctuation(heart_rate_data)

    # Determine drowsiness level based on HRV and fluctuation data
    if hrv < 9:
        overall_state = "Critically Drowsy"
        hrv_state = "Very Low HRV (High Drowsiness Risk)"
    elif 9 <= hrv < 11:
        overall_state = "Slightly Drowsy"
        hrv_state = "Low HRV (Moderate Drowsiness Risk)"
    else:
        overall_state = "Alert/Not Drowsy"
        hrv_state = "Normal HRV (Alert)"

    return {
        "HRV": round(hrv, 2),
        "AverageHR": round(avg_hr, 2),
        "HRVState": hrv_state,
        # "LargeFluctuation": "Yes" if large_fluctuation else "No",
        "OverallState": overall_state
    }

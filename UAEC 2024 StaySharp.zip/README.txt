Project Name

Overview
This project is a web application developed using Django, providing various language support and administrative functionalities. 

Project Structure
- locale/ - Contains translation files for different languages in Django.
- src/ - Main application code (presumed based on typical Django structure).

Prerequisites
- Python 3.x

Setup Instructions

1. Download the zip file and extract all files
   Open the files in VSCode

2. To install dependencies, use:
   pip install -r requirements.txt

3. Database Setup
   Run migrations to set up the database schema.
   python manage.py migrate

4. Start the Development Server
   python manage.py runserver

5. Access the Application
   Open your browser and navigate to http://127.0.0.1:8000.

Language Translations
The project includes various language files located in locale/ directory. These can be modified to support additional languages.

# File: base/heart_rate_analysis.py
import numpy as np
import random

# Generate random heart rate data with realistic fluctuation range
def generate_heart_rate_data(seconds=30, baseline_hr=70):
    """
    Generates heart rate data with more dynamic fluctuations, simulating realistic heart rate patterns.
    Each heart rate is adjusted based on the previous heart rate, with a wider fluctuation range.
    """
    heart_rate_data = []
    current_hr = baseline_hr

    for _ in range(seconds):
        # Increased fluctuation range to simulate more varied heart rates
        fluctuation = random.uniform(-20, 20)
        current_hr = max(40, current_hr + fluctuation)  # Ensure HR stays above 40 bpm
        heart_rate_data.append(current_hr)
        
        # Slight downward drift to simulate ongoing relaxation, if necessary
        baseline_hr -= random.uniform(0, 0.05)

    return heart_rate_data

# Calculate HRV using RMSSD
def calculate_hrv_rmssd(heart_rate_data):
    rr_intervals = np.diff(heart_rate_data)
    squared_diff = np.square(rr_intervals)
    rmssd = np.sqrt(np.mean(squared_diff))
    return rmssd

# Calculate average heart rate
def calculate_average_heart_rate(heart_rate_data):
    return np.mean(heart_rate_data)

# Detect large, sudden changes in heart rate
def has_large_fluctuation(heart_rate_data, threshold=30):
    return any(abs(earlier - later) > threshold for earlier, later in zip(heart_rate_data, heart_rate_data[1:]))

# Analyze heart rate and infer drowsiness level
def infer_state(heart_rate_data, baseline_hr):
    hrv = calculate_hrv_rmssd(heart_rate_data)
    avg_hr = calculate_average_heart_rate(heart_rate_data)
    large_fluctuation = has_large_fluctuation(heart_rate_data)
    
    # Updated thresholds for HRV to create realistic distribution of states
    if hrv < 9:
        overall_state = "Critically Drowsy" if not large_fluctuation else "Erratic (Possible Fatigue)"
        hrv_state = "Very Low HRV (High Drowsiness Risk)"
    elif 9 <= hrv < 11:
        overall_state = "Slightly Drowsy"
        hrv_state = "Low HRV (Moderate Drowsiness Risk)"
    else:  # HRV >= 11
        overall_state = "Alert/Not Drowsy"
        hrv_state = "Normal HRV (Alert)"

    return {
        "HRV": hrv,
        "AverageHR": avg_hr,
        "HRVState": hrv_state,
        "LargeFluctuation": "Yes" if large_fluctuation else "No",
        "OverallState": overall_state
    }

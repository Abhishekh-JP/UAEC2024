# from django.db import models
# from django.contrib.auth.models import User

# class UserProfile(models.Model):
#     user = models.OneToOneField(User, on_delete=models.CASCADE)
#     is_driver = models.BooleanField(default=True)
#     emergency_contact = models.CharField(max_length=15, blank=True, null=True)

#     def __str__(self):
#         return f"{self.user.username} - {'Driver' if self.is_driver else 'Operator'}"

# class DrowsinessEvent(models.Model):
#     user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="drowsiness_events")
#     timestamp = models.DateTimeField(auto_now_add=True)
#     severity = models.CharField(max_length=10, choices=[("low", "Low"), ("medium", "Medium"), ("high", "High")])
#     duration_seconds = models.PositiveIntegerField(help_text="Duration of drowsiness detected in seconds")

#     def __str__(self):
#         return f"{self.user.username} - {self.severity} severity at {self.timestamp}"

# class Alert(models.Model):
#     event = models.ForeignKey(DrowsinessEvent, on_delete=models.CASCADE, related_name="alerts")
#     timestamp = models.DateTimeField(auto_now_add=True)
#     alert_type = models.CharField(max_length=50, choices=[("visual", "Visual"), ("audio", "Audio"), ("vibration", "Vibration")])
#     alert_status = models.CharField(max_length=12, choices=[("sent", "Sent"), ("acknowledged", "Acknowledged")], default="sent")

#     def __str__(self):
#         return f"Alert for {self.event.user.username} - {self.alert_type} at {self.timestamp}"


# File: base/models.py
from django.db import models
from django.contrib.auth.models import User

class DrowsinessCheck(models.Model):
    """
    Stores a record of each drowsiness check, including the heart rate variability (HRV),
    average heart rate, and overall state (e.g., 'Alert', 'Slightly Drowsy', 'Critically Drowsy').
    """
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    hrv = models.FloatField()
    average_hr = models.FloatField()
    state = models.CharField(max_length=50)

    def __str__(self):
        return f"DrowsinessCheck by {self.user.username} at {self.timestamp} - State: {self.state}"

class AlertLog(models.Model):
    """
    Logs alerts that have been sent to users, allowing tracking of when an alert was issued
    and for which drowsiness state.
    """
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    alert_timestamp = models.DateTimeField(auto_now_add=True)
    message = models.TextField()
    state = models.CharField(max_length=50)  # Stores the state that triggered the alert (e.g., "Critically Drowsy")

    def __str__(self):
        return f"AlertLog for {self.user.username} at {self.alert_timestamp} - State: {self.state}"

class UserProfile(models.Model):
    """
    Extends the default user model to store additional user-specific information if needed.
    For example, we could store baseline heart rate, preferred email for notifications, etc.
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    baseline_hr = models.FloatField(default=70.0)  # Optional baseline heart rate for analysis
    preferred_email = models.EmailField(blank=True, null=True)  # Optional, in case user wants alerts sent elsewhere

    def __str__(self):
        return f"UserProfile for {self.user.username}"



# # File: base/views.py
# from django.shortcuts import render
# from .heart_rate_analysis import generate_heart_rate_data, infer_state

# # Home page view
# def home_view(request):
#     return render(request, 'base/index.html')

# # Monitor page view with automatic heart rate analysis
# def monitor_view(request):
#     baseline_hr = 70  # Example baseline for testing
#     heart_rate_data = generate_heart_rate_data()
#     analysis = infer_state(heart_rate_data, baseline_hr)
    
#     # Set alert_needed to True only if the user is in a critical state
#     alert_needed = analysis["OverallState"] in ["Drowsy", "Stressed/Alert"]
    
#     return render(request, 'base/monitor.html', {'analysis': analysis, 'alert_needed': alert_needed})

# # Alert page view with specific message based on state
# def alert_view(request):
#     # Retrieve the analysis state passed from the monitor page (if implemented with session or URL parameters)
#     analysis_state = request.GET.get('state', 'unknown')
    
#     # Customize alert message based on state
#     if analysis_state == "Drowsy":
#         alert_message = "Drowsiness Detected! Please take a break."
#     elif analysis_state == "Stressed/Alert":
#         alert_message = "High Stress Detected! Please try to relax."
#     else:
#         alert_message = "Stay safe and monitor your health."

#     return render(request, 'base/alert.html', {'alert_message': alert_message})

# File: base/views.py
from django.shortcuts import render, redirect
from django.utils import timezone
from django.contrib.auth.decorators import user_passes_test
from django.urls import reverse
from django.http import HttpResponseRedirect
# from .email_service import send_email_alert  # Commented out for now
from .heart_rate_analysis import generate_heart_rate_data, infer_state
from .models import DrowsinessCheck

def is_superuser(user):
    return user.is_superuser

@user_passes_test(is_superuser)
def home_view(request):
    """
    Home page view.
    """
    return render(request, 'base/index.html')

@user_passes_test(is_superuser)
def monitor_view(request):
    baseline_hr = 70  # Example baseline for testing
    heart_rate_data = generate_heart_rate_data()
    analysis = infer_state(heart_rate_data, baseline_hr)
    
    # Debugging: Print the analysis results to check if the drowsiness state is always critical
    print("Heart Rate Data:", heart_rate_data)
    print("Analysis:", analysis)
    
    # Create a DrowsinessCheck entry in the database to log the analysis
    check = DrowsinessCheck.objects.create(
        user=request.user,
        timestamp=timezone.now(),
        hrv=analysis["HRV"],
        average_hr=analysis["AverageHR"],
        state=analysis["OverallState"]
    )

    # Check if an alert is needed based on drowsiness state
    alert_needed = analysis["OverallState"] in ["Critically Drowsy", "Slightly Drowsy"]

    return render(request, 'base/monitor.html', {
        'analysis': analysis,
        'alert_needed': alert_needed
    })

@user_passes_test(is_superuser)
def alert_view(request):
    """
    This view displays an alert page if the user is in a critical drowsiness state.
    The message shown is based on the critical drowsiness state detected.
    """
    # Retrieve the critical state from the URL parameter (if passed)
    analysis_state = request.GET.get('state', 'unknown')
    
    # Customize alert message based on the detected drowsiness state
    if analysis_state == "Critically Drowsy":
        alert_message = "High drowsiness detected! Please take a break immediately."
    elif analysis_state == "Slightly Drowsy":
        alert_message = "Slight drowsiness detected. Consider taking a break if you feel tired."
    else:
        alert_message = "Stay safe and monitor your health."

    return render(request, 'base/alert.html', {
        'alert_message': alert_message
    })

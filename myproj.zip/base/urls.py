# File: base/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('monitor/', views.monitor_view, name='monitor'),
    path('alert/', views.alert_view, name='alert'),  # Alert page route
]
